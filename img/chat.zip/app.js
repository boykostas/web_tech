function send() {
    var message = document.getElementById('text').value;
    document.getElementById('text').value = '';
    (async () => {
        var response = await fetch('chat.php?message=' + message);
        var answer = await response.text();

    }
)();
}

function get() {
    (async () => {
        var response = await fetch('chat.php');
        var answer = await response.text();
        document.getElementById('messages').innerText = answer;
    }
)();
}

get();

setInterval(get, 2000);